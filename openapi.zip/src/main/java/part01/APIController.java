package part01;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class APIController {
	
	@RequestMapping(value="/test.do")
	public ModelAndView function() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("view/index");
		return mav;
	}
	
	@RequestMapping(value="/result.do", method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView process(String startYear, String siDo) {
		ModelAndView mav = new ModelAndView();
		BufferedReader br = null;
		try {
			String urlstr = "http://apis.data.go.kr/B552061/trafficAccidentDeath/getRestTrafficAccidentDeath?"
					+ "&searchYear=" + startYear + "&siDo=" + siDo.trim()
					+ "&ServiceKey=adcbrLqgCjFcj%2FF1ZpRhqpPzCHjP7sWqpIujzyEhntJeWXjEIXQUjCHB4GjfONiG5vg8ya05C6E%2BADfvDQFyWQ%3D%3D";
			URL url = new URL(urlstr);
			HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
			urlConn.setRequestMethod("GET");
			br = new BufferedReader(new InputStreamReader(urlConn.getInputStream(),"UTF-8"));
			String result = "";
			String line;
			while((line = br.readLine()) != null) {
				result = result + line + "\n";
			}
			mav.addObject("res",result);
			mav.setViewName("redirect:/test.do");
			//System.out.println(result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mav;
	}
	
}//end class
