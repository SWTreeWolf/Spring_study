package part02;

import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.github.scribejava.core.model.OAuth2AccessToken;

@Controller
public class NaverController {
	/*@RequestMapping("/nlogin.do")
	public ModelAndView login() {
		ModelAndView mav = new ModelAndView();
		String message = "login";
		mav.addObject("message",message);
		mav.setViewName("view/nindex");
		return mav;
	}
	
	@RequestMapping("/cback.do")
	public ModelAndView callback() {
		ModelAndView mav = new ModelAndView();
		String message = "call back";
		mav.addObject("message",message);
		mav.setViewName("view/nindex");
		return mav;
	}*/
	
	private NaverLoginBO naverLoginBO;
	private String apiResult = null;
	
	public void setNaverLoginBO(NaverLoginBO naverLoginBO) {
		this.naverLoginBO = naverLoginBO;
	}
	
	//로그인 첫 화면 요청 메소드
	@RequestMapping(value = "/nlogin.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView login(HttpSession session) {
		/* 네이버아이디로 인증 URL을 생성하기 위하여 naverLoginBO클래스의 getAuthorizationUrl메소드 호출 */
		ModelAndView mav = new ModelAndView();
        String naverAuthUrl = naverLoginBO.getAuthorizationUrl(session);
        /*네이버:https://nid.naver.com/oauth2.0/authorize?
         * response_type=code&client_id=eB2rbSnacIsF3QBmhecX
         * &redirect_uri=http%3A%2F%2Flocalhost%3A8090%2Fapi%2Fcback.do
         * &state=86117d1a-dd8e-4c77-bac6-52ce9c9e8554
         */        
        System.out.println("네이버:" + naverAuthUrl);
        //네이버
        mav.addObject("url",naverAuthUrl);
        mav.setViewName("view/naverlogin");

        /* 생성한 인증 URL을 View로 전달 */
        return mav;
	}
	
	//네이버 로그인 성공시 callback호출 메소드
    @RequestMapping(value = "/cback.do", method = { RequestMethod.GET, RequestMethod.POST })
    public ModelAndView callback(@RequestParam String code, @RequestParam String state, HttpSession session)
            throws IOException {
        System.out.println("----------------------여기는 callback");
        ModelAndView mav = new ModelAndView();
        
        OAuth2AccessToken oauthToken;
        oauthToken = naverLoginBO.getAccessToken(session, code, state);
        
        //로그인 사용자 정보를 읽어온다.
        apiResult = naverLoginBO.getUserProfile(oauthToken);
        
        //{"resultcode":"00","message":"success","response":{"id":"26134425","gender":"M","email":"luerune@jr.naver.com","name":"\uc2e0\uc2b9\uc6b0"}}
        System.out.println(naverLoginBO.getUserProfile(oauthToken).toString());
        
        mav.addObject("result",apiResult);
        //result{"resultcode":"00","message":"success","response":{"id":"26134425","gender":"M","email":"luerune@jr.naver.com","name":"\uc2e0\uc2b9\uc6b0"}}
        System.out.println("result"+apiResult);
        
        mav.setViewName("view/naverSuccess");
        /* 네이버 로그인 성공 페이지 View 호출 */
//      JSONObject jsonobj = jsonparse.stringToJson(apiResult, "response");
//      String snsId = jsonparse.JsonToString(jsonobj, "id");
//      String name = jsonparse.JsonToString(jsonobj, "name");
//
//      UserVO vo = new UserVO();
//      vo.setUser_snsId(snsId);
//      vo.setUser_name(name);
//
//      System.out.println(name);
//      try {
//          vo = service.naverLogin(vo);
//      } catch (Exception e) {
//          // TODO Auto-generated catch block
//          e.printStackTrace();
//      }


//      session.setAttribute("login",vo);
//      return new ModelAndView("user/loginPost", "result", vo);
        
        return mav;
    }
}
